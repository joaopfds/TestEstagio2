package com.estagio2.folders.resource;

public class PostsResource {

}
