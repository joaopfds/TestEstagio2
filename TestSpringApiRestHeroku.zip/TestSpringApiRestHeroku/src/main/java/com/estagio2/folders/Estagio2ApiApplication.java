package com.estagio2.folders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Estagio2ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Estagio2ApiApplication.class, args);
	}
}
